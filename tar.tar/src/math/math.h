#ifndef MATH_H
#define MATH_H

int math_pow ( int base, int exponent );

int math_intLength ( int intNumber );

float math_abs ( float absNumber );

#endif //MATH_H
