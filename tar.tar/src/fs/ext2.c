#include "ext2.h"

void test(void) {
	serialf("len: %d\n", sizeof(ext2_inode_t));
}


