#ifndef ext2_H
#define ext2_H

typedef	unsigned	char	extl1;
typedef	unsigned	short	extl2;
typedef	unsigned	int		extl4;

#include "ext2_superblock.h"
#include "ext2_block_group_descriptor.h"
#include "ext2_inode.h"

void test ( void );



#endif //ext2_H
