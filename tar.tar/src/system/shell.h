#ifndef SHELL_H
#define SHELL_H

void startShell();

void doShell();

#endif //SHELL_H
