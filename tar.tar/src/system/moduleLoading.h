#include "../common.h"

void runModule ( s8int ( *func ) ( void ) );
