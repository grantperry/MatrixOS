#include "elf.h"
#include "fs.h"

void load() {
	FILE *bin;
	bin = ( FILE* ) f_open ( "binary.o", fs_root, "r" );
	serialf ( "Binary openend\n" );
	char *buf = ( char* ) kmalloc ( sizeof ( char ) * 1024 );
	f_read ( bin, 0, 1024, buf );
	serialf("\n\n%s\n", buf);
}
