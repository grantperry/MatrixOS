#ifndef SPECIAL_KEYS_H
#define SPECIAL_KEYS_H
#include "../common.h"
void doSpecial ( u16int i );
//F1=1
//F12=12

#endif //SPECIAL_KEYS_H
