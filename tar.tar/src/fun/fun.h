#ifndef FUN_H
#define FUN_H

void colour_fun();

#endif
