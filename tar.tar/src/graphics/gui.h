#ifndef GUI_H
#define GUI_H
#include "../stdio.h"
#include "../common.h"

void startgui ( int look );

void drawBackground();

void drawBar();

#endif // GUI_H
