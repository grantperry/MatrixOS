/*
//	PCI Express Driver
//	MatrixOS
//	Refer to ~MatrixOS/docs/references/phy-interface-pci-express-sata-usb31-architectures-ver43.pdf
*/
#include "pci.h"
#include "../common.h"

void pci_bus_scan()
{
	unsigned int bus,dev,fun,num_fun;
	//register unsigned int *temp = new unsigned int[4];
	PCI_common *cfg;
	pci_dev *pd;
	if(!is_pci_present())
	{
		serialf("No PCI bus...!\n");
		return;
	}
	for(bus=0;bus<255;bus++)
	{
		for(dev=0;dev<32;dev++)
		{
			if(pci_read_config_byte(bus,dev,0,0x0e)==0x80)
				num_fun=8;
			else 
				num_fun=1;

			for(fun=0;fun<num_fun;fun++)
			{
				unsigned int *temp=new unsigned int[4];
				memset(temp,'0',4*sizeof(unsigned int));
				for(int i=0;i<4;i++)
				{
					temp[i]=pci_read_config_dword(bus,dev,fun,i<<2);
				}
				cfg=(struct PCI_common*)temp;
				if((cfg->vendor_id==0xffff) || (cfg->vendor_id==0x0000))
				{
					delete[] temp;
					continue;
				}
				num_dev++;
				pd=new pci_dev;
				if(!pd) halt();
				pd->bus=bus;
				pd->dev=dev;
				pd->func=fun;
				for(int i=0;i<60;i++)
					pd->devi[i]=pci_read_config_dword(bus,dev,fun,(i<<2)+16);
				pd->prev=0;
				pd->next=0;
				pd->common=cfg;
				pd->irq = pci_read_irq(bus,dev,fun);
				pci_set_master(pd);
				if(pci_list==0)
				{
					pci_list=pd;
					end=pci_list;
					pci_list->next=0;
					pci_list->prev=0;
				}
				else
				{
					pd->prev=end;
					end->next=pd;
					pd->next=0;
					end=pd;
				}
				serialf("*");
			}// end fun
		}// end dev
	}//end bus
	cout<<"\n";
}


void init_PCI() {
	//pci_scan();

#ifdef PCIE_H
	init_PCIe();
#endif//PCIE_H
}
