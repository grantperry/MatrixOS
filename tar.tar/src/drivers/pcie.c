#include "pcie.h"
#include "pci.h"

void init_PCIe() {
	serialf ( "[PCI][Express] Initializing\n" );
}
