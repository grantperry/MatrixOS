#ifndef PCIE_H
#define PCIE_H

void init_PCIe();

#endif//PCIE_H
