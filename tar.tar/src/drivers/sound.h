#ifndef SOUND_H
#define SOUND_H
#include "../stdio.h"
void play_sound(u32int nFrequence);
void nosound();
void beep();
#endif //SOUND_H
