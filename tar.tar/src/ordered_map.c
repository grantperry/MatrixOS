// MatrixOS - ordered_array.c
// Implementation for creating, inserting and deleting
// from ordered arrays.

#include <ordered_array.h>

