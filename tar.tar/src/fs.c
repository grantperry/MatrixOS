#include "fs.h"
#include "vfs.h"

//the curent directory node
void *currentDirectory;

//initial file descriptor location
file_desc_t *initial_file_desc;

/*
// Checks weather the file is already open or not.
*/
file_desc_t *lookup_file_desc ( void *node ) {
	file_desc_t *temp_desc;
	temp_desc = initial_file_desc; //make a copy so we dont muck it up.

	for ( ; temp_desc != node && temp_desc; temp_desc = temp_desc->next ) {}

	if ( !temp_desc ) {
		return 0; //descriptor is null, return 0.
	}

	return temp_desc;
}

//TODO actually read the file
u32int f_read(file_desc_t *file, u32int offset, u32int size, u8int *buffer) {
	file_desc_t *fdesc;
	fdesc = ( file_desc_t* ) lookup_file_desc ( file->node );

	//we did not find the file desc in the list
	if ( !fdesc ) {
		return 0; //error
	}

	if ( ! ( fdesc->permisions & FDESC_READ ) ) {
		return 0;
	}

	switch ( fdesc->fs_type ) {
	case M_UNKNOWN:
		return 0; //error

	case M_VFS:

		//check if this node has a callback
		if ( ( ( fs_node_t* ) fdesc->node )->read ) {
			return ( ( fs_node_t* ) fdesc->node )->read ( fdesc->node, offset, size, buffer );

		} else {
			break;
		}

	case M_EXT2:
		//return ext2_read(fdesc->node, offset, size, buffer);
		printf ( "TODO Support ext2-4\n" );
		break;

	default:
		return 0; //error
	}
}

u32int f_write ( FILE *node, u32int offset, u32int size, u8int *buffer ) {
	//check if this FILE node is in the file descriptor list
	file_desc_t *fdesc;
	fdesc = lookup_file_desc ( node->node );

	//we did not find the file desc in the list
	if ( !fdesc ) {
		return 1; //error
	}

	//if the size writing to the node is larger than its size + offset, expand it
	if ( offset + size > node->size )

		//TODO f_expand(node, (offset + size) - node->size);

		//if the user can read from it
		if ( fdesc->permisions & FDESC_WRITE ) {
			switch ( fdesc->fs_type ) {
			case M_UNKNOWN:
				return 1; //error

			case M_VFS:

				//check if this node has a callback
				if ( ( ( fs_node_t* ) fdesc->node )->write ) {
					return ( ( fs_node_t* ) fdesc->node )->write ( fdesc->node, offset, size, buffer );

				} else {
					break;
				}

			/*case M_EXT2:
			  return ext2_write(fdesc->node, offset, size, buffer);*/
			default:
				return 1; //error
			}

		} else {
			printf ( "Error: writing to an unprivilaged file\n" );
		}

	//if we have not exited yet, it is an error
	return 1;
}

FILE *__open__( void *node, char *name, char *mask, u8int open ) {
	if (node) {
		file_desc_t *tmp_desc;
		tmp_desc = initial_file_desc;
		
		for ( ; tmp_desc->next != 0; tmp_desc = tmp_desc->next ) {
			if (tmp_desc->node == node) {
				return tmp_desc; //no point in returning error
			}
		}
		file_desc_t *new_desc; //new descriptor for the list
		new_desc = (file_desc_t*)kmalloc(sizeof(file_desc_t));
		u16int new_name_len;
		new_name_len = strlen(name); //get the name and transfer it.
		new_desc->name = ( char* ) kmalloc ( new_name_len + 1 ); // +1 for the \000
		
	}
	return 0; //cause your a fail!
}

FILE *f_open(char *filename, void *dir, char *mask)
{
  if(!dir)
    return 0; //error
	printf("opening file \"%s\"\n", filename);
  FILE *file;
  file = (FILE *)f_finddir(dir, filename);

  //a file already exists to be opened
  if(file)
  {
	}

  //if we are outside, return an error
  return 0;

}

FILE *f_finddir ( void *node, char *name ) {
	
}

char *name_of_dir ( void *node ) {
	
}
