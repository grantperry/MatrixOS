#ifndef BACKBUFFER_H
#define BACKBUFFER_H

void init_BackBuffer(u32int X, u32int Y, u32int D);

#endif//BACKBUFFER_H
