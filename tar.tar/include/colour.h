// MatrixOS - colour.h
// Definitions of bios text mode colours
#ifndef COLOUR_H
#define COLOUR_H

#define BLACK			0
#define DARK_BLUE		1
#define DARK_GREEN		2
#define DARK_CYAN		3
#define REN				4
#define DARK_MAGNETA	5
#define BROWN			6
#define GREY			7
#define DARK_GREY		8
#define BLUE			9
#define GREEN			10
#define CYAN			11
#define RED				12
#define MAGNETA			13
#define YELLOW			14
#define WHITE			15

#endif
