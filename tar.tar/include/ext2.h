#ifndef ext2_H
#define ext2_H

typedef	unsigned	char	extl1;
typedef	unsigned	short	extl2;
typedef	unsigned	int		extl4;

void test(void);



#endif //ext2_H
