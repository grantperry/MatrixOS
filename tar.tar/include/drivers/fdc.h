#ifndef FDC_H
#define FDC_H

void init_fdc();

#endif//FDC_H
