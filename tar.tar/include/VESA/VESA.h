#ifndef VESA_H
#define VESA_H

// VESA Assembly Functions
u16int testvesa();
//////////////////////////

void setVesa(u32int mode);

#endif//VESA_H
