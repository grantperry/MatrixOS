#include <stdio.h>
#ifndef BIN_FLAT_H
#define BIN_FLAT_H

void load_flat(char* name, u32int loc);

#endif//BIN_FLAT_H
