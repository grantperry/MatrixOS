#include <stdio.h>

int main() {
  printf ("Hi World\n");
  return 0;
}
