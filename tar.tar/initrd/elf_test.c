//this file is used for testing elf binary execution
int main(void)
{
	return 0;
}

